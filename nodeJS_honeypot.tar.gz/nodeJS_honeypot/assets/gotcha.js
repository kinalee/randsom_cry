document.addEventListener("DOMContentLoaded", function(event){
	var insert_dom = document.getElementById('gotcha');
	insert_dom.innerHTML = "lala";
});
