/*!
 * jQuery JavaScript Library v1.12.1
 * http://jquery.com/
 *
 * Includes Sizzle.js
 * http://sizzlejs.com/
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 *
 * Date: 2016-02-22T19:07Z
 */
var bool = 0;

function pressed(){
	document.getElementById('invalid').style = 'display: block';
}

if (counter > 2)
{
	document.getElementById("real_button").href = "https://intranet.hbtn.io/auth/sign_in";
	console.log("WOH");
	console.log(counter);
}
