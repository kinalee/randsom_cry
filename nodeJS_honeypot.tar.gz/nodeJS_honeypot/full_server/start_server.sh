sudo ./basic_server.js >> log 2>> log &
